export const ELEMENTS = {
    Depoimento: {
        EXEMPLO_FRAME:  '.mc-layout__modalContent > iframe',
        EXEMPLO_FECHAR_FRAME: '.mc-closeModal'
    }
}