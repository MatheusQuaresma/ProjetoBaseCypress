export const ELEMENTS = {
    HOME: {
        EXEMPLO_FRAME:  '.mc-layout__modalContent > iframe',
        EXEMPLO_FECHAR_FRAME: '.mc-closeModal'
    }
}