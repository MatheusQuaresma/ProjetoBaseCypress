/// <reference types="cypress" />

//importando métodos básicos
import Base from '../base_page'

// elementos da página
const el = require('./elements').ELEMENTS;

export class Head extends Base{

    static acessar_site() {
        cy.visit('/');
    }

}