export const ELEMENTS = {
    Head: {
        CAMPO_BUSCA:  "input[name = 'palavra_busca']",
        BTN_BUSCAR: 'form[class="search-header"] > button[class="button-search"]'
    }
}