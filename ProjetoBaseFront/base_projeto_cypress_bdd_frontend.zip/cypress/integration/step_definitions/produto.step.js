/// <reference types="cypress" />
import {Given, When, Then, Before} from 'cypress-cucumber-preprocessor/steps'

//páginas
import {Head} from '../../pages/head_page'
import {Home} from '../../pages/home'
import {Produto} from '../../pages/produto'

//background / contexto
Given(`que esteja na página home da loja manetzeetech`, () => {
    Head.acessar_site()
})

When(`procurar por um produto usando o campo de busca`, () => {
    cy.stepNotImplemented()
})

When(`selecionar a categoria {string}`, (param1) => {
    cy.stepNotImplemented()
})

When(`escolher o primeiro produto em destaque`, () => {
    cy.stepNotImplemented()
})

Then(`deverá apresentar o resultado da pesquisa`, () => {
    cy.stepNotImplemented()
})

Then(`deverá apresentar a lista de produtos da categoria selecionada`, () => {
    cy.stepNotImplemented()
})

Then(`deverá apresentar as informações do produto na página do produto`, () => {
    cy.stepNotImplemented()
})